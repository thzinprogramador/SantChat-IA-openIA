# SantChat - IA Interna Santander

Protótipo de uma IA inteligente para uso interno no banco Santander, com:

- Aprendizado via comando `/sntevksi`
- Logs por IP
- Controle de acesso via senha configurável
- Integração com OpenAI GPT-3.5-turbo
- Projeto pensado para rodar no Streamlit Cloud usando `st.secrets`

## Como rodar localmente

1. Clone o repositório
2. Crie um arquivo `.env` com as variáveis:
```
OPENAI_API_KEY=sua_chave_openai
SENHA_ATIVADA=true
SENHA_PADRAO=1234
```
3. Instale as dependências:
```
pip install -r requirements.txt
```
4. Rode o app:
```
streamlit run app.py
```

## Deploy no Streamlit Cloud

1. Suba o repositório no GitHub
2. No painel do Streamlit Cloud, configure as Secrets:
```
OPENAI_API_KEY=sk-...
SENHA_ATIVADA=true
SENHA_PADRAO=1234
```
3. Rode o app direto na nuvem.

---

## Observações

- A IA só aprende quando recebe o comando `/sntevksi` seguido do texto a aprender.
- Logs são salvos em `/logs/<IP>/` para auditoria.
- Não armazena dados sensíveis, apenas texto que o usuário fornecer.

---

Projeto desenvolvido por Thiago Henrique via ChatGPT.